"""
Repository para operaciones de Usuario
"""
from typing import Optional, Dict, Any
from app.repositories.base import BaseRepository
from app.core.database import Database


class UserRepository(BaseRepository):
    """Repository para la tabla usuarios"""
    
    def __init__(self):
        super().__init__("usuarios")
    
    async def get_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Obtiene un usuario por email"""
        query = "SELECT * FROM usuarios WHERE email = $1"
        return await Database.fetch_one(query, email)
    
    async def create(
        self,
        email: str,
        nombre: str,
        password_hash: str,
        telefono: Optional[str] = None,
        avatar_url: Optional[str] = None,
        rol: str = "usuario"
    ) -> Dict[str, Any]:
        """Crea un nuevo usuario"""
        query = """
            INSERT INTO usuarios (email, nombre, password, telefono, avatar_url, rol)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        """
        return await Database.fetch_one(
            query, email, nombre, password_hash, telefono, avatar_url, rol
        )
    
    async def update(
        self,
        user_id: str,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Actualiza un usuario"""
        allowed_fields = {"nombre", "telefono", "avatar_url"}
        fields = {k: v for k, v in kwargs.items() if k in allowed_fields and v is not None}
        
        if not fields:
            return await self.get_by_id(user_id)
        
        set_clause = ", ".join([f"{k} = ${i}" for i, k in enumerate(fields.keys(), 1)])
        values = list(fields.values()) + [user_id]
        
        query = f"UPDATE usuarios SET {set_clause} WHERE id = ${len(values)} RETURNING *"
        return await Database.fetch_one(query, *values)
    
    async def update_role(self, user_id: str, rol: str) -> Optional[Dict[str, Any]]:
        """Actualiza el rol de un usuario"""
        query = "UPDATE usuarios SET rol = $1 WHERE id = $2 RETURNING *"
        return await Database.fetch_one(query, rol, user_id)
    
    async def get_all_admins(self) -> list:
        """Obtiene todos los administradores"""
        query = "SELECT * FROM usuarios WHERE rol = 'admin' ORDER BY created_at DESC"
        return await Database.fetch_all(query)
    
    async def email_exists(self, email: str) -> bool:
        """Verifica si un email ya existe"""
        user = await self.get_by_email(email)
        return user is not None
