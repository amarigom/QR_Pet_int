"""
Repository para operaciones de Códigos QR
"""
from typing import Optional, Dict, Any, List
from app.repositories.base import BaseRepository
from app.core.database import Database


class QRRepository(BaseRepository):
    """Repository para la tabla codigos_qr"""
    
    def __init__(self):
        super().__init__("codigos_qr")
    
    async def create(
        self,
        codigo: str,
        mascota_id: Optional[str] = None,
        activo: bool = True
    ) -> Dict[str, Any]:
        """Crea un nuevo QR"""
        query = """
            INSERT INTO codigos_qr (codigo, mascota_id, activo)
            VALUES ($1, $2, $3)
            RETURNING *
        """
        return await Database.fetch_one(query, codigo, mascota_id, activo)
    
    async def get_by_code(self, codigo: str) -> Optional[Dict[str, Any]]:
        """Obtiene un QR por código"""
        query = "SELECT * FROM codigos_qr WHERE codigo = $1"
        return await Database.fetch_one(query, codigo.upper())
    
    async def get_by_mascota(self, mascota_id: str) -> Optional[Dict[str, Any]]:
        """Obtiene QR por ID de mascota"""
        query = "SELECT * FROM codigos_qr WHERE mascota_id = $1"
        return await Database.fetch_one(query, mascota_id)
    
    async def link_mascota(self, qr_id: str, mascota_id: str) -> Optional[Dict[str, Any]]:
        """Vincula un QR a una mascota"""
        query = "UPDATE codigos_qr SET mascota_id = $1 WHERE id = $2 RETURNING *"
        return await Database.fetch_one(query, mascota_id, qr_id)
    
    async def get_available(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene QRs disponibles (sin mascota)"""
        query = """
            SELECT * FROM codigos_qr 
            WHERE mascota_id IS NULL AND activo = true
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        """
        return await Database.fetch_all(query, limit, offset)
    
    async def get_all_with_details(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene todos los QRs con detalles"""
        query = """
            SELECT q.*, m.nombre as mascota_nombre, u.nombre as owner_name
            FROM codigos_qr q
            LEFT JOIN mascotas m ON q.mascota_id = m.id
            LEFT JOIN usuarios u ON m.usuario_id = u.id
            ORDER BY q.created_at DESC
            LIMIT $1 OFFSET $2
        """
        return await Database.fetch_all(query, limit, offset)
    
    async def code_exists(self, codigo: str) -> bool:
        """Verifica si un código QR ya existe"""
        qr = await self.get_by_code(codigo)
        return qr is not None
