"""
Repository para operaciones de Escaneos
"""
from typing import Optional, Dict, Any, List
from app.repositories.base import BaseRepository
from app.core.database import Database


class ScanRepository(BaseRepository):
    """Repository para la tabla escaneos"""
    
    def __init__(self):
        super().__init__("escaneos")
    
    async def create(
        self,
        qr_id: str,
        latitud: Optional[float] = None,
        longitud: Optional[float] = None,
        direccion_aproximada: Optional[str] = None,
        mensaje_encontrador: Optional[str] = None,
        telefono_encontrador: Optional[str] = None
    ) -> Dict[str, Any]:
        """Crea un nuevo escaneo"""
        query = """
            INSERT INTO escaneos 
            (qr_id, latitud, longitud, direccion_aproximada, mensaje_encontrador, telefono_encontrador)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        """
        return await Database.fetch_one(
            query, qr_id, latitud, longitud, direccion_aproximada, 
            mensaje_encontrador, telefono_encontrador
        )
    
    async def get_by_qr(self, qr_id: str, limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene escaneos de un QR"""
        query = """
            SELECT * FROM escaneos 
            WHERE qr_id = $1
            ORDER BY created_at DESC
            LIMIT $2 OFFSET $3
        """
        return await Database.fetch_all(query, qr_id, limit, offset)
    
    async def count_by_qr(self, qr_id: str) -> int:
        """Cuenta escaneos de un QR"""
        query = "SELECT COUNT(*) FROM escaneos WHERE qr_id = $1"
        return await Database.fetch_val(query, qr_id)
    
    async def get_all_with_details(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene todos los escaneos con detalles"""
        query = """
            SELECT e.*, m.nombre as mascota_nombre, u.nombre as owner_name
            FROM escaneos e
            JOIN codigos_qr q ON e.qr_id = q.id
            JOIN mascotas m ON q.mascota_id = m.id
            JOIN usuarios u ON m.usuario_id = u.id
            ORDER BY e.created_at DESC
            LIMIT $1 OFFSET $2
        """
        return await Database.fetch_all(query, limit, offset)
    
    async def get_by_mascota(self, mascota_id: str, limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene escaneos de una mascota"""
        query = """
            SELECT e.* FROM escaneos e
            JOIN codigos_qr q ON e.qr_id = q.id
            WHERE q.mascota_id = $1
            ORDER BY e.created_at DESC
            LIMIT $2 OFFSET $3
        """
        return await Database.fetch_all(query, mascota_id, limit, offset)
    
    async def count_recent_scans(self, days: int = 30) -> int:
        """Cuenta escaneos recientes"""
        query = """
            SELECT COUNT(*) FROM escaneos 
            WHERE created_at >= NOW() - INTERVAL '%d days'
        """ % days
        return await Database.fetch_val(query)
