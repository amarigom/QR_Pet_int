"""
Repository para operaciones de Mascotas
"""
from typing import Optional, Dict, Any, List
from app.repositories.base import BaseRepository
from app.core.database import Database


class PetRepository(BaseRepository):
    """Repository para la tabla mascotas"""
    
    def __init__(self):
        super().__init__("mascotas")
    
    async def create(
        self,
        usuario_id: str,
        nombre: str,
        especie: str,
        raza: Optional[str] = None,
        color: Optional[str] = None,
        edad_aproximada: Optional[str] = None,
        foto_url: Optional[str] = None,
        notas: Optional[str] = None,
        estado: str = "activo"
    ) -> Dict[str, Any]:
        """Crea una nueva mascota"""
        query = """
            INSERT INTO mascotas 
            (usuario_id, nombre, especie, raza, color, edad_aproximada, foto_url, notas, estado)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            RETURNING *
        """
        return await Database.fetch_one(
            query, usuario_id, nombre, especie, raza, color, 
            edad_aproximada, foto_url, notas, estado
        )
    
    async def update(
        self,
        pet_id: str,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Actualiza una mascota"""
        allowed_fields = {"nombre", "raza", "color", "edad_aproximada", "foto_url", "notas", "estado"}
        fields = {k: v for k, v in kwargs.items() if k in allowed_fields and v is not None}
        
        if not fields:
            return await self.get_by_id(pet_id)
        
        set_clause = ", ".join([f"{k} = ${i}" for i, k in enumerate(fields.keys(), 1)])
        values = list(fields.values()) + [pet_id]
        
        query = f"UPDATE mascotas SET {set_clause} WHERE id = ${len(values)} RETURNING *"
        return await Database.fetch_one(query, *values)
    
    async def get_by_user(self, usuario_id: str, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene mascotas de un usuario"""
        query = """
            SELECT * FROM mascotas 
            WHERE usuario_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        """
        return await Database.fetch_all(query, usuario_id, limit, offset)
    
    async def count_by_user(self, usuario_id: str) -> int:
        """Cuenta las mascotas de un usuario"""
        query = "SELECT COUNT(*) FROM mascotas WHERE usuario_id = $1"
        return await Database.fetch_val(query, usuario_id)
    
    async def get_by_qr(self, qr_id: str) -> Optional[Dict[str, Any]]:
        """Obtiene mascota por ID de QR"""
        query = """
            SELECT m.* FROM mascotas m
            JOIN codigos_qr q ON q.mascota_id = m.id
            WHERE q.id = $1
        """
        return await Database.fetch_one(query, qr_id)
    
    async def get_all_with_owner(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene todas las mascotas con información del dueño"""
        query = """
            SELECT m.*, u.nombre as owner_name, u.email as owner_email
            FROM mascotas m
            JOIN usuarios u ON m.usuario_id = u.id
            ORDER BY m.created_at DESC
            LIMIT $1 OFFSET $2
        """
        return await Database.fetch_all(query, limit, offset)
