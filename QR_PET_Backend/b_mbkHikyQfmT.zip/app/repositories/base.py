"""
Base repository con operaciones CRUD genéricas
"""
from typing import List, Optional, Any, Dict
from app.core.database import Database


class BaseRepository:
    """Clase base para repositorios con operaciones CRUD comunes"""
    
    def __init__(self, table_name: str):
        self.table_name = table_name
    
    async def get_by_id(self, id: str) -> Optional[Dict[str, Any]]:
        """Obtiene un registro por ID"""
        query = f"SELECT * FROM {self.table_name} WHERE id = $1"
        return await Database.fetch_one(query, id)
    
    async def get_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Obtiene todos los registros"""
        query = f"SELECT * FROM {self.table_name} ORDER BY created_at DESC LIMIT $1 OFFSET $2"
        return await Database.fetch_all(query, limit, offset)
    
    async def count(self) -> int:
        """Cuenta el total de registros"""
        query = f"SELECT COUNT(*) FROM {self.table_name}"
        return await Database.fetch_val(query)
    
    async def delete(self, id: str) -> bool:
        """Elimina un registro"""
        query = f"DELETE FROM {self.table_name} WHERE id = $1"
        result = await Database.execute(query, id)
        return result != "DELETE 0"
    
    async def exists(self, id: str) -> bool:
        """Verifica si un registro existe"""
        record = await self.get_by_id(id)
        return record is not None
