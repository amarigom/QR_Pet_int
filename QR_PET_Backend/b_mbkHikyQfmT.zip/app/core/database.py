"""
Gestión de conexiones y pool de base de datos
"""
import asyncpg
from typing import Optional
from app.config import settings

_pool: Optional[asyncpg.Pool] = None


async def get_pool() -> asyncpg.Pool:
    """Obtiene o crea el pool de conexiones"""
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(
            settings.DATABASE_URL,
            min_size=settings.DB_MIN_SIZE,
            max_size=settings.DB_MAX_SIZE,
        )
    return _pool


async def close_pool():
    """Cierra el pool de conexiones"""
    global _pool
    if _pool:
        await _pool.close()
        _pool = None


async def init_db():
    """Inicializa la base de datos (obtiene el pool)"""
    await get_pool()


class Database:
    """Clase helper para operaciones comunes de base de datos"""
    
    @staticmethod
    async def fetch_one(query: str, *args):
        """Obtiene un registro"""
        pool = await get_pool()
        return await pool.fetchrow(query, *args)
    
    @staticmethod
    async def fetch_all(query: str, *args):
        """Obtiene múltiples registros"""
        pool = await get_pool()
        return await pool.fetch(query, *args)
    
    @staticmethod
    async def execute(query: str, *args):
        """Ejecuta un query de modificación"""
        pool = await get_pool()
        return await pool.execute(query, *args)
    
    @staticmethod
    async def fetch_val(query: str, *args):
        """Obtiene un valor único"""
        pool = await get_pool()
        return await pool.fetchval(query, *args)
