"""
Service para autenticación
"""
from datetime import timedelta
from typing import Optional, Dict, Any
from app.core.auth import hash_password, verify_password, create_access_token
from app.core.exceptions import (
    AuthenticationException, ConflictException, ResourceNotFoundException
)
from app.core.constants import MESSAGE_EMAIL_EXISTS, MESSAGE_INVALID_CREDENTIALS
from app.repositories.user_repository import UserRepository
from app.schemas.user import UserResponse, TokenResponse, UserLogin, UserCreate
from app.utils.validators import validate_email, validate_password


class AuthService:
    """Service para lógica de autenticación"""
    
    def __init__(self):
        self.user_repo = UserRepository()
    
    async def register(self, user_data: UserCreate) -> UserResponse:
        """Registra un nuevo usuario"""
        # Validar email
        if not validate_email(user_data.email):
            raise AuthenticationException("Email inválido")
        
        # Validar contraseña
        validate_password(user_data.password)
        
        # Verificar que el email no exista
        if await self.user_repo.email_exists(user_data.email):
            raise ConflictException(MESSAGE_EMAIL_EXISTS)
        
        # Crear usuario
        password_hash = hash_password(user_data.password)
        user = await self.user_repo.create(
            email=user_data.email,
            nombre=user_data.nombre,
            password_hash=password_hash,
            telefono=user_data.telefono,
            avatar_url=user_data.avatar_url,
        )
        
        return UserResponse(
            id=str(user["id"]),
            email=user["email"],
            nombre=user["nombre"],
            telefono=user["telefono"],
            rol=user["rol"],
            avatar_url=user["avatar_url"],
            created_at=user["created_at"],
        )
    
    async def login(self, login_data: UserLogin) -> TokenResponse:
        """Autentica un usuario y retorna token"""
        # Obtener usuario por email
        user = await self.user_repo.get_by_email(login_data.email)
        if not user:
            raise AuthenticationException(MESSAGE_INVALID_CREDENTIALS)
        
        # Verificar contraseña
        if not verify_password(login_data.password, user["password"]):
            raise AuthenticationException(MESSAGE_INVALID_CREDENTIALS)
        
        # Crear token
        access_token = create_access_token(
            data={"sub": str(user["id"]), "email": user["email"], "rol": user["rol"]}
        )
        
        return TokenResponse(
            access_token=access_token,
            user=UserResponse(
                id=str(user["id"]),
                email=user["email"],
                nombre=user["nombre"],
                telefono=user["telefono"],
                rol=user["rol"],
                avatar_url=user["avatar_url"],
                created_at=user["created_at"],
            )
        )
    
    async def get_user(self, user_id: str) -> UserResponse:
        """Obtiene datos de un usuario"""
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ResourceNotFoundException("Usuario")
        
        return UserResponse(
            id=str(user["id"]),
            email=user["email"],
            nombre=user["nombre"],
            telefono=user["telefono"],
            rol=user["rol"],
            avatar_url=user["avatar_url"],
            created_at=user["created_at"],
        )
