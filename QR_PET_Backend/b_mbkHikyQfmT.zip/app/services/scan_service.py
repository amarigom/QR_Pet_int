"""
Service para operaciones de Escaneos
"""
from typing import Dict, Any
from app.repositories.scan_repository import ScanRepository
from app.repositories.qr_repository import QRRepository
from app.core.exceptions import ResourceNotFoundException
from app.schemas.scan import ScanCreate, ScanResponse


class ScanService:
    """Service para lógica de escaneos"""
    
    def __init__(self):
        self.scan_repo = ScanRepository()
        self.qr_repo = QRRepository()
    
    async def create_scan(self, scan_data: ScanCreate) -> Dict[str, Any]:
        """Registra un nuevo escaneo"""
        # Obtener QR
        qr = await self.qr_repo.get_by_code(scan_data.codigo)
        if not qr:
            raise ResourceNotFoundException("Código QR", "Código QR no encontrado")
        
        # Crear escaneo
        scan = await self.scan_repo.create(
            qr_id=qr["id"],
            latitud=scan_data.latitud,
            longitud=scan_data.longitud,
            direccion_aproximada=scan_data.direccion_aproximada,
            mensaje_encontrador=scan_data.mensaje_encontrador,
            telefono_encontrador=scan_data.telefono_encontrador,
        )
        
        return {
            "success": True,
            "message": "Escaneo registrado correctamente",
            "scan": ScanResponse(
                id=str(scan["id"]),
                qr_id=str(scan["qr_id"]),
                latitud=float(scan["latitud"]) if scan["latitud"] else None,
                longitud=float(scan["longitud"]) if scan["longitud"] else None,
                direccion_aproximada=scan["direccion_aproximada"],
                mensaje_encontrador=scan["mensaje_encontrador"],
                telefono_encontrador=scan["telefono_encontrador"],
                created_at=scan["created_at"],
            ),
        }
    
    async def get_pet_scans(self, pet_id: str, page: int = 1, limit: int = 20) -> Dict[str, Any]:
        """Obtiene escaneos de una mascota"""
        offset = (page - 1) * limit
        scans = await self.scan_repo.get_by_mascota(pet_id, limit, offset)
        count = await self.scan_repo.count_by_qr(pet_id)
        
        return {
            "items": [
                ScanResponse(
                    id=str(s["id"]),
                    qr_id=str(s["qr_id"]),
                    latitud=float(s["latitud"]) if s["latitud"] else None,
                    longitud=float(s["longitud"]) if s["longitud"] else None,
                    direccion_aproximada=s["direccion_aproximada"],
                    mensaje_encontrador=s["mensaje_encontrador"],
                    telefono_encontrador=s["telefono_encontrador"],
                    created_at=s["created_at"],
                ) for s in scans
            ],
            "total": count,
            "page": page,
            "limit": limit,
        }
    
    async def get_all_scans(self, page: int = 1, limit: int = 100) -> Dict[str, Any]:
        """Obtiene todos los escaneos (admin)"""
        offset = (page - 1) * limit
        scans = await self.scan_repo.get_all_with_details(limit, offset)
        
        return {
            "items": scans,
            "page": page,
            "limit": limit,
        }
