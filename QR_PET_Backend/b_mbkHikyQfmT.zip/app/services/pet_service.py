"""
Service para operaciones de Mascotas
"""
from typing import List, Optional, Dict, Any
from app.repositories.pet_repository import PetRepository
from app.repositories.qr_repository import QRRepository
from app.core.exceptions import ResourceNotFoundException, InvalidDataException
from app.schemas.pet import PetCreate, PetUpdate, PetResponse, PetDetailResponse


class PetService:
    """Service para lógica de mascotas"""
    
    def __init__(self):
        self.pet_repo = PetRepository()
        self.qr_repo = QRRepository()
    
    async def create_pet(self, user_id: str, pet_data: PetCreate) -> PetDetailResponse:
        """Crea una nueva mascota"""
        pet = await self.pet_repo.create(
            usuario_id=user_id,
            nombre=pet_data.nombre,
            especie=pet_data.especie,
            raza=pet_data.raza,
            color=pet_data.color,
            edad_aproximada=pet_data.edad_aproximada,
            foto_url=pet_data.foto_url,
            notas=pet_data.notas,
        )
        
        # Obtener QR asociado si existe
        qr = await self.qr_repo.get_by_mascota(pet["id"])
        
        return PetDetailResponse(
            id=str(pet["id"]),
            usuario_id=str(pet["usuario_id"]),
            nombre=pet["nombre"],
            especie=pet["especie"],
            raza=pet["raza"],
            color=pet["color"],
            edad_aproximada=pet["edad_aproximada"],
            foto_url=pet["foto_url"],
            notas=pet["notas"],
            estado=pet["estado"],
            created_at=pet["created_at"],
            qr_id=str(qr["id"]) if qr else None,
            qr_code=qr["codigo"] if qr else None,
        )
    
    async def get_pet(self, user_id: str, pet_id: str) -> PetDetailResponse:
        """Obtiene detalles de una mascota"""
        pet = await self.pet_repo.get_by_id(pet_id)
        if not pet or str(pet["usuario_id"]) != user_id:
            raise ResourceNotFoundException("Mascota")
        
        qr = await self.qr_repo.get_by_mascota(pet["id"])
        
        return PetDetailResponse(
            id=str(pet["id"]),
            usuario_id=str(pet["usuario_id"]),
            nombre=pet["nombre"],
            especie=pet["especie"],
            raza=pet["raza"],
            color=pet["color"],
            edad_aproximada=pet["edad_aproximada"],
            foto_url=pet["foto_url"],
            notas=pet["notas"],
            estado=pet["estado"],
            created_at=pet["created_at"],
            qr_id=str(qr["id"]) if qr else None,
            qr_code=qr["codigo"] if qr else None,
        )
    
    async def get_user_pets(self, user_id: str, page: int = 1, limit: int = 20) -> Dict[str, Any]:
        """Obtiene mascotas de un usuario con paginación"""
        offset = (page - 1) * limit
        pets = await self.pet_repo.get_by_user(user_id, limit, offset)
        total = await self.pet_repo.count_by_user(user_id)
        
        return {
            "items": [
                PetResponse(
                    id=str(p["id"]),
                    usuario_id=str(p["usuario_id"]),
                    nombre=p["nombre"],
                    especie=p["especie"],
                    raza=p["raza"],
                    color=p["color"],
                    edad_aproximada=p["edad_aproximada"],
                    foto_url=p["foto_url"],
                    notas=p["notas"],
                    estado=p["estado"],
                    created_at=p["created_at"],
                ) for p in pets
            ],
            "total": total,
            "page": page,
            "limit": limit,
            "pages": (total + limit - 1) // limit,
        }
    
    async def update_pet(self, user_id: str, pet_id: str, pet_data: PetUpdate) -> PetResponse:
        """Actualiza una mascota"""
        pet = await self.pet_repo.get_by_id(pet_id)
        if not pet or str(pet["usuario_id"]) != user_id:
            raise ResourceNotFoundException("Mascota")
        
        updated_pet = await self.pet_repo.update(pet_id, **pet_data.model_dump(exclude_unset=True))
        
        return PetResponse(
            id=str(updated_pet["id"]),
            usuario_id=str(updated_pet["usuario_id"]),
            nombre=updated_pet["nombre"],
            especie=updated_pet["especie"],
            raza=updated_pet["raza"],
            color=updated_pet["color"],
            edad_aproximada=updated_pet["edad_aproximada"],
            foto_url=updated_pet["foto_url"],
            notas=updated_pet["notas"],
            estado=updated_pet["estado"],
            created_at=updated_pet["created_at"],
        )
    
    async def delete_pet(self, user_id: str, pet_id: str) -> bool:
        """Elimina una mascota"""
        pet = await self.pet_repo.get_by_id(pet_id)
        if not pet or str(pet["usuario_id"]) != user_id:
            raise ResourceNotFoundException("Mascota")
        
        return await self.pet_repo.delete(pet_id)
