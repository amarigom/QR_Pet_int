"""
Service para operaciones administrativas
"""
from typing import Dict, Any
from app.repositories.user_repository import UserRepository
from app.repositories.pet_repository import PetRepository
from app.core.exceptions import ResourceNotFoundException, InvalidDataException
from app.core.constants import UserRole, MESSAGE_CANNOT_DELETE_SELF, MESSAGE_CANNOT_MODIFY_SELF_ROLE
from app.schemas.user import UserResponse


class AdminService:
    """Service para lógica administrativa"""
    
    def __init__(self):
        self.user_repo = UserRepository()
        self.pet_repo = PetRepository()
    
    async def get_all_users(self, page: int = 1, limit: int = 50) -> Dict[str, Any]:
        """Obtiene todos los usuarios"""
        offset = (page - 1) * limit
        users = await self.user_repo.get_all(limit, offset)
        total = await self.user_repo.count()
        
        return {
            "items": [
                UserResponse(
                    id=str(u["id"]),
                    email=u["email"],
                    nombre=u["nombre"],
                    telefono=u["telefono"],
                    rol=u["rol"],
                    avatar_url=u["avatar_url"],
                    created_at=u["created_at"],
                ) for u in users
            ],
            "total": total,
            "page": page,
            "limit": limit,
        }
    
    async def delete_user(self, admin_id: str, user_id: str) -> bool:
        """Elimina un usuario"""
        if str(admin_id) == user_id:
            raise InvalidDataException(MESSAGE_CANNOT_DELETE_SELF)
        
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ResourceNotFoundException("Usuario")
        
        return await self.user_repo.delete(user_id)
    
    async def toggle_admin_role(self, admin_id: str, user_id: str) -> UserResponse:
        """Cambia el rol de un usuario entre admin y usuario"""
        if str(admin_id) == user_id:
            raise InvalidDataException(MESSAGE_CANNOT_MODIFY_SELF_ROLE)
        
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ResourceNotFoundException("Usuario")
        
        new_role = UserRole.USER if user["rol"] == UserRole.ADMIN else UserRole.ADMIN
        updated_user = await self.user_repo.update_role(user_id, new_role)
        
        return UserResponse(
            id=str(updated_user["id"]),
            email=updated_user["email"],
            nombre=updated_user["nombre"],
            telefono=updated_user["telefono"],
            rol=updated_user["rol"],
            avatar_url=updated_user["avatar_url"],
            created_at=updated_user["created_at"],
        )
    
    async def get_dashboard_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del dashboard"""
        total_users = await self.user_repo.count()
        total_pets = await self.pet_repo.count()
        
        return {
            "total_users": total_users,
            "total_pets": total_pets,
        }
