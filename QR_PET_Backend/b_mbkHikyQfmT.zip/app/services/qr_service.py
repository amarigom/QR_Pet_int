"""
Service para operaciones de Códigos QR
"""
from typing import List, Dict, Any
from app.repositories.qr_repository import QRRepository
from app.repositories.pet_repository import PetRepository
from app.core.auth import generate_qr_code
from app.core.exceptions import ResourceNotFoundException, InvalidDataException
from app.core.constants import MESSAGE_QR_NOT_FOUND, MESSAGE_QR_ALREADY_LINKED
from app.schemas.qr import QRResponse, QRDetailResponse, QRActivateData


class QRService:
    """Service para lógica de códigos QR"""
    
    def __init__(self):
        self.qr_repo = QRRepository()
        self.pet_repo = PetRepository()
    
    async def generate_qrs(self, cantidad: int) -> Dict[str, Any]:
        """Genera múltiples QRs sin mascota asociada"""
        created_qrs = []
        
        for _ in range(cantidad):
            codigo = generate_qr_code()
            qr = await self.qr_repo.create(codigo=codigo, mascota_id=None, activo=True)
            
            created_qrs.append(QRResponse(
                id=str(qr["id"]),
                codigo=qr["codigo"],
                mascota_id=None,
                activo=qr["activo"],
                created_at=qr["created_at"],
            ))
        
        return {
            "created": len(created_qrs),
            "qrs": created_qrs,
        }
    
    async def get_qr(self, qr_id: str) -> QRDetailResponse:
        """Obtiene detalles de un QR"""
        qr = await self.qr_repo.get_by_id(qr_id)
        if not qr:
            raise ResourceNotFoundException("Código QR")
        
        return QRDetailResponse(
            id=str(qr["id"]),
            codigo=qr["codigo"],
            mascota_id=str(qr["mascota_id"]) if qr["mascota_id"] else None,
            activo=qr["activo"],
            created_at=qr["created_at"],
        )
    
    async def get_all_qrs(self, page: int = 1, limit: int = 50) -> Dict[str, Any]:
        """Obtiene todos los QRs con detalles"""
        offset = (page - 1) * limit
        qrs = await self.qr_repo.get_all_with_details(limit, offset)
        
        return {
            "items": [
                QRDetailResponse(
                    id=str(q["id"]),
                    codigo=q["codigo"],
                    mascota_id=str(q["mascota_id"]) if q["mascota_id"] else None,
                    mascota_nombre=q.get("mascota_nombre"),
                    owner_name=q.get("owner_name"),
                    activo=q["activo"],
                    created_at=q["created_at"],
                ) for q in qrs
            ],
            "page": page,
            "limit": limit,
        }
    
    async def check_qr_availability(self, codigo: str) -> Dict[str, Any]:
        """Verifica si un QR está disponible para activar"""
        qr = await self.qr_repo.get_by_code(codigo)
        
        if not qr:
            return {
                "available": False,
                "message": "Código no encontrado",
            }
        
        if qr["mascota_id"]:
            return {
                "available": False,
                "message": "Ya está vinculado a una mascota",
                "has_pet": True,
            }
        
        return {
            "available": True,
            "message": "Disponible para activar",
        }
    
    async def activate_qr(self, user_id: str, activate_data: QRActivateData) -> Dict[str, Any]:
        """Activa un QR y lo vincula a una nueva mascota"""
        qr = await self.qr_repo.get_by_code(activate_data.codigo)
        
        if not qr:
            raise ResourceNotFoundException("Código QR", MESSAGE_QR_NOT_FOUND)
        
        if qr["mascota_id"]:
            raise InvalidDataException(MESSAGE_QR_ALREADY_LINKED)
        
        # Crear mascota
        pet = await self.pet_repo.create(
            usuario_id=user_id,
            nombre=activate_data.nombre,
            especie=activate_data.especie,
            raza=activate_data.raza,
            color=activate_data.color,
            edad_aproximada=activate_data.edad_aproximada,
            foto_url=activate_data.foto_url,
            notas=activate_data.notas,
        )
        
        # Vincular QR a mascota
        await self.qr_repo.link_mascota(qr["id"], pet["id"])
        
        return {
            "message": "QR activado correctamente",
            "pet_id": str(pet["id"]),
            "qr_id": str(qr["id"]),
        }
    
    async def delete_qr(self, qr_id: str) -> bool:
        """Elimina un QR"""
        exists = await self.qr_repo.exists(qr_id)
        if not exists:
            raise ResourceNotFoundException("Código QR")
        
        return await self.qr_repo.delete(qr_id)
