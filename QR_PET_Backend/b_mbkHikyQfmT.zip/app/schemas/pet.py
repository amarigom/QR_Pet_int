"""
Esquemas (Pydantic models) para Mascotas
"""
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from app.core.constants import PetStatus, AnimalSpecies


class PetBase(BaseModel):
    """Base para mascota"""
    nombre: str = Field(..., min_length=1, max_length=100)
    especie: AnimalSpecies
    raza: Optional[str] = Field(None, max_length=100)
    color: Optional[str] = Field(None, max_length=100)
    edad_aproximada: Optional[str] = None
    foto_url: Optional[str] = None
    notas: Optional[str] = None


class PetCreate(PetBase):
    """Schema para crear mascota"""
    pass


class PetUpdate(BaseModel):
    """Schema para actualizar mascota"""
    nombre: Optional[str] = Field(None, min_length=1, max_length=100)
    raza: Optional[str] = Field(None, max_length=100)
    color: Optional[str] = Field(None, max_length=100)
    edad_aproximada: Optional[str] = None
    foto_url: Optional[str] = None
    notas: Optional[str] = None
    estado: Optional[PetStatus] = None


class PetResponse(BaseModel):
    """Schema de respuesta de mascota"""
    id: str
    usuario_id: str
    nombre: str
    especie: str
    raza: Optional[str]
    color: Optional[str]
    edad_aproximada: Optional[str]
    foto_url: Optional[str]
    notas: Optional[str]
    estado: str
    created_at: datetime

    class Config:
        from_attributes = True


class PetDetailResponse(PetResponse):
    """Schema detallado de mascota"""
    qr_code: Optional[str] = None
    qr_id: Optional[str] = None


class PetWithOwner(PetResponse):
    """Mascota con información del dueño"""
    owner_name: Optional[str] = None
    owner_email: Optional[str] = None
