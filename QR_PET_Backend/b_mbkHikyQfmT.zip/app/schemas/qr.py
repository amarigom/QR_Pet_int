"""
Esquemas (Pydantic models) para Códigos QR
"""
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class QRBase(BaseModel):
    """Base para QR"""
    codigo: str


class QRCreate(BaseModel):
    """Schema para crear QR"""
    cantidad: int = Field(1, ge=1, le=100)


class QRResponse(BaseModel):
    """Schema de respuesta de QR"""
    id: str
    codigo: str
    mascota_id: Optional[str] = None
    activo: bool
    created_at: datetime

    class Config:
        from_attributes = True


class QRDetailResponse(QRResponse):
    """QR con detalles de mascota"""
    mascota_nombre: Optional[str] = None
    owner_name: Optional[str] = None


class QRActivateData(BaseModel):
    """Schema para activar un QR"""
    codigo: str = Field(..., min_length=1)
    nombre: str = Field(..., min_length=1, max_length=100)
    especie: str
    raza: Optional[str] = None
    color: Optional[str] = None
    edad_aproximada: Optional[str] = None
    foto_url: Optional[str] = None
    notas: Optional[str] = None


class QRCheckResponse(BaseModel):
    """Schema de respuesta para verificar QR"""
    available: bool
    message: str
    has_pet: Optional[bool] = None
