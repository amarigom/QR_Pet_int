"""
Esquemas comunes de respuesta
"""
from pydantic import BaseModel
from typing import Optional, Any, List


class MessageResponse(BaseModel):
    """Respuesta con solo mensaje"""
    message: str


class SuccessResponse(BaseModel):
    """Respuesta genérica de éxito"""
    success: bool = True
    message: str
    data: Optional[Any] = None


class ErrorResponse(BaseModel):
    """Respuesta genérica de error"""
    success: bool = False
    message: str
    errors: Optional[Any] = None


class PaginatedResponse(BaseModel):
    """Respuesta paginada genérica"""
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int


class CreatedResponse(BaseModel):
    """Respuesta de creación"""
    created: int
    items: List[Any]
