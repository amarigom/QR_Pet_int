"""
Esquemas (Pydantic models) para Usuario
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime
from app.core.constants import UserRole


class UserBase(BaseModel):
    """Base para usuario"""
    email: EmailStr
    nombre: str = Field(..., min_length=1, max_length=100)
    telefono: Optional[str] = None
    avatar_url: Optional[str] = None


class UserCreate(UserBase):
    """Schema para crear usuario"""
    password: str = Field(..., min_length=6)


class UserUpdate(BaseModel):
    """Schema para actualizar usuario"""
    nombre: Optional[str] = Field(None, min_length=1, max_length=100)
    telefono: Optional[str] = None
    avatar_url: Optional[str] = None


class UserResponse(BaseModel):
    """Schema de respuesta de usuario"""
    id: str
    email: str
    nombre: str
    telefono: Optional[str]
    rol: UserRole
    avatar_url: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class UserAdmin(UserResponse):
    """Schema de usuario para admin"""
    rol: UserRole


class UserLogin(BaseModel):
    """Schema para login"""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Schema de respuesta de token"""
    access_token: str
    token_type: str = "bearer"
    user: UserResponse
