"""
Esquemas (Pydantic models) para Escaneos
"""
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class ScanBase(BaseModel):
    """Base para escaneo"""
    qr_id: str
    latitud: Optional[float] = None
    longitud: Optional[float] = None
    direccion_aproximada: Optional[str] = None
    mensaje_encontrador: Optional[str] = None
    telefono_encontrador: Optional[str] = None


class ScanCreate(BaseModel):
    """Schema para crear escaneo (público)"""
    codigo: str = Field(..., min_length=1)
    latitud: Optional[float] = None
    longitud: Optional[float] = None
    direccion_aproximada: Optional[str] = None
    mensaje_encontrador: Optional[str] = None
    telefono_encontrador: Optional[str] = None


class ScanResponse(BaseModel):
    """Schema de respuesta de escaneo"""
    id: str
    qr_id: str
    latitud: Optional[float] = None
    longitud: Optional[float] = None
    direccion_aproximada: Optional[str] = None
    mensaje_encontrador: Optional[str] = None
    telefono_encontrador: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ScanDetailResponse(ScanResponse):
    """Escaneo con detalles de mascota"""
    mascota_nombre: Optional[str] = None
    owner_name: Optional[str] = None
