"""
Endpoints para Mascotas
"""
from fastapi import APIRouter, Depends, Query
from app.schemas.pet import PetCreate, PetUpdate, PetResponse, PetDetailResponse
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.pet_service import PetService
from app.api.v1.dependencies import get_current_user

router = APIRouter(prefix="/pets", tags=["pets"])
pet_service = PetService()


@router.post("", response_model=PetDetailResponse)
async def create_pet(pet_data: PetCreate, user: dict = Depends(get_current_user)):
    """Crea una nueva mascota"""
    return await pet_service.create_pet(user["id"], pet_data)


@router.get("", response_model=dict)
async def get_pets(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    user: dict = Depends(get_current_user)
):
    """Obtiene las mascotas del usuario autenticado"""
    return await pet_service.get_user_pets(user["id"], page, limit)


@router.get("/{pet_id}", response_model=PetDetailResponse)
async def get_pet(pet_id: str, user: dict = Depends(get_current_user)):
    """Obtiene detalles de una mascota"""
    return await pet_service.get_pet(user["id"], pet_id)


@router.put("/{pet_id}", response_model=PetResponse)
async def update_pet(
    pet_id: str,
    pet_data: PetUpdate,
    user: dict = Depends(get_current_user)
):
    """Actualiza una mascota"""
    return await pet_service.update_pet(user["id"], pet_id, pet_data)


@router.delete("/{pet_id}", response_model=SuccessResponse)
async def delete_pet(pet_id: str, user: dict = Depends(get_current_user)):
    """Elimina una mascota"""
    await pet_service.delete_pet(user["id"], pet_id)
    return SuccessResponse(message="Mascota eliminada correctamente")
