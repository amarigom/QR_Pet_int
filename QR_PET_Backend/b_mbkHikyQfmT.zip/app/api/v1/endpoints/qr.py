"""
Endpoints para Códigos QR
"""
from fastapi import APIRouter, Depends, Query
from app.schemas.qr import QRResponse, QRActivateData, QRCheckResponse, QRDetailResponse
from app.schemas.common import SuccessResponse, CreatedResponse
from app.services.qr_service import QRService
from app.api.v1.dependencies import get_current_user, require_admin

router = APIRouter(prefix="/qr", tags=["qr"])
qr_service = QRService()


@router.post("/generate", response_model=dict)
async def generate_qrs(
    cantidad: int = Query(1, ge=1, le=100),
    user: dict = Depends(require_admin)
):
    """Admin: Genera nuevos códigos QR sin mascota asociada"""
    return await qr_service.generate_qrs(cantidad)


@router.get("", response_model=dict)
async def list_qrs(
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(require_admin)
):
    """Admin: Lista todos los códigos QR"""
    return await qr_service.get_all_qrs(page, limit)


@router.get("/{qr_id}", response_model=QRDetailResponse)
async def get_qr_details(qr_id: str, user: dict = Depends(require_admin)):
    """Admin: Obtiene detalles de un QR"""
    return await qr_service.get_qr(qr_id)


@router.delete("/{qr_id}", response_model=SuccessResponse)
async def delete_qr(qr_id: str, user: dict = Depends(require_admin)):
    """Admin: Elimina un QR"""
    await qr_service.delete_qr(qr_id)
    return SuccessResponse(message="Código QR eliminado correctamente")


@router.post("/activate", response_model=dict)
async def activate_qr(
    data: QRActivateData,
    user: dict = Depends(get_current_user)
):
    """Usuario: Activa un QR y lo vincula a una nueva mascota"""
    return await qr_service.activate_qr(user["id"], data)


@router.get("/check/{code}", response_model=QRCheckResponse)
async def check_qr_availability(code: str):
    """Público: Verifica si un QR está disponible"""
    return await qr_service.check_qr_availability(code)
