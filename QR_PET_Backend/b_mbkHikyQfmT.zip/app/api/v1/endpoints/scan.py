"""
Endpoints para Escaneos
"""
from fastapi import APIRouter, Depends, Query
from app.schemas.scan import ScanCreate, ScanResponse
from app.schemas.common import SuccessResponse
from app.services.scan_service import ScanService
from app.api.v1.dependencies import get_current_user, require_admin

router = APIRouter(prefix="/scans", tags=["scans"])
scan_service = ScanService()


@router.post("", response_model=dict)
async def create_scan(scan_data: ScanCreate):
    """Público: Registra un nuevo escaneo de mascota encontrada"""
    return await scan_service.create_scan(scan_data)


@router.get("", response_model=dict)
async def get_all_scans(
    page: int = Query(1, ge=1),
    limit: int = Query(100, ge=1, le=500),
    user: dict = Depends(require_admin)
):
    """Admin: Obtiene todos los escaneos"""
    return await scan_service.get_all_scans(page, limit)


@router.get("/pet/{pet_id}", response_model=dict)
async def get_pet_scans(
    pet_id: str,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    user: dict = Depends(get_current_user)
):
    """Usuario: Obtiene escaneos de su mascota"""
    return await scan_service.get_pet_scans(pet_id, page, limit)
