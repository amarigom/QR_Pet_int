"""
Endpoints para autenticación
"""
from fastapi import APIRouter, Depends
from app.schemas.user import UserCreate, UserLogin, TokenResponse, UserResponse
from app.services.auth_service import AuthService
from app.api.v1.dependencies import get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])
auth_service = AuthService()


@router.post("/register", response_model=UserResponse)
async def register(user_data: UserCreate):
    """Registra un nuevo usuario"""
    return await auth_service.register(user_data)


@router.post("/login", response_model=TokenResponse)
async def login(login_data: UserLogin):
    """Autentica un usuario y retorna un token"""
    return await auth_service.login(login_data)


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(user: dict = Depends(get_current_user)):
    """Obtiene información del usuario autenticado"""
    return await auth_service.get_user(user["id"])
