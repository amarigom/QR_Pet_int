"""
Endpoints administrativos
"""
from fastapi import APIRouter, Depends, Query
from app.schemas.user import UserResponse
from app.schemas.common import SuccessResponse
from app.services.admin_service import AdminService
from app.api.v1.dependencies import require_admin

router = APIRouter(prefix="/admin", tags=["admin"])
admin_service = AdminService()


@router.get("/users", response_model=dict)
async def get_all_users(
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(require_admin)
):
    """Admin: Obtiene todos los usuarios"""
    return await admin_service.get_all_users(page, limit)


@router.delete("/users/{user_id}", response_model=SuccessResponse)
async def delete_user(user_id: str, admin: dict = Depends(require_admin)):
    """Admin: Elimina un usuario"""
    await admin_service.delete_user(admin["id"], user_id)
    return SuccessResponse(message="Usuario eliminado correctamente")


@router.post("/users/{user_id}/toggle-admin", response_model=UserResponse)
async def toggle_admin_role(user_id: str, admin: dict = Depends(require_admin)):
    """Admin: Cambia el rol de un usuario"""
    return await admin_service.toggle_admin_role(admin["id"], user_id)


@router.get("/stats", response_model=dict)
async def get_dashboard_stats(user: dict = Depends(require_admin)):
    """Admin: Obtiene estadísticas del dashboard"""
    return await admin_service.get_dashboard_stats()
