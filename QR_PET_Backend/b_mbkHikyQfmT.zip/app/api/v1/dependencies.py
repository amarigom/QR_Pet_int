"""
Dependencias y funciones compartidas para endpoints
"""
from typing import Optional
from fastapi import Depends, Header
from app.core.auth import decode_access_token
from app.core.exceptions import AuthenticationException, PermissionDeniedException
from app.repositories.user_repository import UserRepository
from app.core.constants import UserRole


async def get_current_user(authorization: Optional[str] = Header(None)) -> dict:
    """Obtiene el usuario actual del token JWT"""
    if not authorization or not authorization.startswith("Bearer "):
        raise AuthenticationException("Token no proporcionado")
    
    token = authorization.split(" ")[1]
    payload = decode_access_token(token)
    
    user_repo = UserRepository()
    user = await user_repo.get_by_id(payload.get("sub"))
    
    if not user:
        raise AuthenticationException("Usuario no encontrado")
    
    return user


async def require_admin(user: dict = Depends(get_current_user)) -> dict:
    """Requiere que el usuario sea administrador"""
    if user["rol"] != UserRole.ADMIN:
        raise PermissionDeniedException("Se requieren permisos de administrador")
    
    return user


async def get_optional_user(authorization: Optional[str] = Header(None)) -> Optional[dict]:
    """Obtiene el usuario actual si existe, sino retorna None"""
    if not authorization or not authorization.startswith("Bearer "):
        return None
    
    try:
        return await get_current_user(authorization)
    except AuthenticationException:
        return None
