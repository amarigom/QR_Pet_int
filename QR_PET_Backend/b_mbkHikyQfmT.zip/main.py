"""
Aplicación principal de FastAPI
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from app.config import settings
from app.core.database import init_db, close_pool
from app.middleware import setup_middleware
from app.api.v1.router import router as v1_router
from app.utils.logger import logger


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Maneja eventos de inicio y cierre de la aplicación"""
    # Startup
    logger.info("Iniciando aplicación...")
    await init_db()
    logger.info("Base de datos conectada")
    
    yield
    
    # Shutdown
    logger.info("Cerrando aplicación...")
    await close_pool()
    logger.info("Pool de base de datos cerrado")


# Crear aplicación FastAPI
app = FastAPI(
    title=settings.API_TITLE,
    version=settings.API_VERSION,
    lifespan=lifespan,
    debug=settings.DEBUG,
)

# Configurar middleware
setup_middleware(app)

# Incluir routers
app.include_router(v1_router)


# Health check endpoint
@app.get("/health")
async def health_check():
    """Endpoint para verificar la salud de la aplicación"""
    return {"status": "ok"}


# Root endpoint
@app.get("/")
async def root():
    """Endpoint raíz"""
    return {
        "message": "Bienvenido a PetFinder API",
        "version": settings.API_VERSION,
        "docs": "/docs",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
    )
